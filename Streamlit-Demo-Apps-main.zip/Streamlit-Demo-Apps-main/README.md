Este es el repositorio de aplicaciones de ejemplo con Streamlit, que acompañan los videos del canal [https://www.youtube.com/@ElLocodelosDatos](https://www.youtube.com/@ElLocodelosDatos)
* **appInicio.py:** Aplicación básica de inicio con un filtro y 2 charts en Plotly
* **dashboardVentas.py:** Ejemplo de un dashboard de ventas para una tienda online de productos tecnológicos
* **streamlitProphetForecasting** : Carpeta con aplicación de ejemplo de carga y descarga de archivos en Streamlit, usando una proyección de serie de tiempo con Prophet
