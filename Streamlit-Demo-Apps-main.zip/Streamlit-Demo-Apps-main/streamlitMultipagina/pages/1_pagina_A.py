import streamlit as st
import utilidades as util
util.generarMenu()
st.header('Página A')